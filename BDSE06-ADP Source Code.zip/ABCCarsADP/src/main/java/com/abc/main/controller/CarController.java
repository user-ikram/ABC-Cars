package com.abc.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.abc.main.entity.CarBidding;
import com.abc.main.entity.Cars;
import com.abc.main.entity.Users;
import com.abc.main.service.BidService;
import com.abc.main.service.CarService;

@Controller
public class CarController {
	
	@Autowired
	private CarService carService;
	
	@Autowired
	private BidService bidService;
	
	@RequestMapping(value = "cars", method = RequestMethod.GET)
	public ModelAndView listAllCar(ModelAndView mav) {
		List<Cars> listcars = carService.listAllCars();
		if(!CollectionUtils.isEmpty(listcars)) {
			mav.addObject("listcars", listcars);
		} else {
			mav.addObject("list_empty", "Sorry. The Car List is empty");
		}
		
		mav.setViewName("home");
		return mav;
	}
	
	@RequestMapping(value = "all_car", method = RequestMethod.GET)
	public ModelAndView listAllCars(ModelAndView mav) {
		List<Cars> listcars = carService.listAllCars();
		if(!CollectionUtils.isEmpty(listcars)) {
			mav.addObject("listcars", listcars);
		} else {
			mav.addObject("list-empty", "Sorry. The Car List is empty");
		}
		
		mav.setViewName("allcar");
		return mav;
	}
	
	@RequestMapping(value = "car_detail", method = RequestMethod.GET)
    public ModelAndView viewCar(@RequestParam long id, ModelAndView mav) {
    	Cars car = carService.getCarById(id);
    	List<CarBidding> bidinfo = bidService.listAllBidInfo(car);
    	Users user = car.getUser();
    	mav.addObject("car", car);
    	mav.addObject("bidinfo", bidinfo);
    	mav.addObject("user", user);
    	mav.setViewName("cardetail");
    	
    	return mav;
    }
	
	@RequestMapping(value="new_car",  method= RequestMethod.GET)
    public ModelAndView newCarForm(@ModelAttribute("car") Cars car, ModelAndView mav) {
    	mav.setViewName("addnewcar");
    	return mav;
    }
	
	@RequestMapping(value = "save_car", method = RequestMethod.POST)
    public ModelAndView saveCar(@ModelAttribute("car") Cars car, ModelAndView mav) {
    	
    	if(car.getId() == null) {
    		carService.addCar(car);
    	} else {
    		carService.editCar(car);
    	}
    	
    	mav.setViewName("redirect:cars");
    	return mav;
    }
	
	@RequestMapping(value="edit_car",  method= RequestMethod.GET)
    public ModelAndView editCarForm(@RequestParam long id, ModelAndView mav) {
    	Cars car = carService.getCarById(id);
    	mav.addObject("car", car);
    	mav.setViewName("editcar");
    	return mav;
    }
	
	@RequestMapping(value = "delete_car")
    public ModelAndView deleteCar(@RequestParam long id, ModelAndView mav) {
    	carService.deleteCar(id);
    	mav.setViewName("redirect:all_car");
    	return mav;
    }
	
	@RequestMapping(value = "deactivate_car")
    public ModelAndView deactivateCar(@RequestParam long id, ModelAndView mav) {
    	carService.inactiveCar(id);
    	mav.setViewName("redirect:all_car");
    	return mav;
    }
    
    @RequestMapping(value = "activate_car")
    public ModelAndView activateCar(@RequestParam long id, ModelAndView mav) {
    	carService.activeCar(id);
    	mav.setViewName("redirect:all_car");
    	return mav;
    }
    
    @RequestMapping(value = "search_param")
    public ModelAndView searchWithKey(@RequestParam(value = "keyword", required = false) String keyword,
    								  ModelAndView mav) {
    	List<Cars> result = carService.searchByParam(keyword);
    	
    	if(result == null || result.isEmpty()) {
    		mav.addObject("msg_result", "Sorry we couldn't find any result  '"+keyword+"'");
    	} else {
    		mav.addObject("msg_result", "Result of your search for '"+keyword+"'");
    		mav.addObject("listcars", result);
    	}
    	mav.setViewName("searchresult");
    	return mav;
    }
	
}
