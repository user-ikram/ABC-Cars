package com.abc.main.config;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.abc.main.entity.Roles;
import com.abc.main.entity.Users;
import com.abc.main.repository.UserRepo;

@Transactional
public class UserDetailServiceImpl implements UserDetailsService{
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	public UserDetailServiceImpl() {
	}
	
	private static Logger logger = LoggerFactory.getLogger(UserDetailServiceImpl.class);
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		logger.info("Login UserName: "+username);
		Users users = userRepo.findByUserName(username);
		
		System.out.println("Login is working");
		System.out.println(username);
		
		if(users == null) {
			throw new UsernameNotFoundException("user " + username + " is not valid. Please re-enter.");
		}
		
		org.springframework.security.core.userdetails.User.UserBuilder userBuilder = org.springframework.security.core.userdetails.User.builder();
		
		String[] roleNames = users.getRoles().stream().map(Roles::getName).toArray(String[]::new);
		
		logger.info("Role name: " + roleNames);
		
		return userBuilder.username(users.getUserName())
						  .password(users.getPassword())
						  .roles(roleNames)
						  .passwordEncoder(passwordEncoder::encode)
						  .build();
	}

}
