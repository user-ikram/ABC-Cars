package com.abc.main.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.main.entity.CarBidding;
import com.abc.main.entity.Cars;
import com.abc.main.repository.CarBidRepo;

@Service
@Transactional
public class BidService {
	
	@Autowired
	private CarBidRepo carBidRepo;
	
	public List<CarBidding> listAllBidInfo(Cars car){
		return carBidRepo.findByCarId(car);
	}

}
