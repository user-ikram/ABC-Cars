package com.abc.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbcCarsAdpApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbcCarsAdpApplication.class, args);
	}

}
