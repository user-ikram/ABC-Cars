package com.abc.main;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.abc.main.entity.Cars;
import com.abc.main.entity.Users;
import com.abc.main.repository.CarRepo;
import com.abc.main.repository.UserRepo;
import com.abc.main.service.CarService;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = SecurityTestConfig.class)
@SpringBootTest(classes = AbcCarsAdpApplicationTests.class)
public class UnitTest {
	
	@Autowired
	private WebApplicationContext webContext;
	
	private MockMvc mvc;
	
	@Mock
	CarRepo carRepo;
	
	@Mock
	UserRepo userRepo;
	
	@InjectMocks
	CarService carService;
	
	@BeforeEach
	public void setup() {
		mvc = MockMvcBuilders
				.webAppContextSetup(webContext)
				.apply(springSecurity())
				.build();
	}
	
	@Test
	@WithMockUser(value="users")
	public void testIndexWithUser() throws Exception {
		mvc.perform(get("/"));
	}
	
	@Test
	void testDeleteCar() {
		long carid = 1;
		carService.deleteCar(carid);
		
		verify(carRepo, times(1)).deleteById(carid);
	}
	
	@Test
	void testListCarUser() {
		Optional<Users> user = userRepo.findById(2L);
		
		if(user.isPresent()) {
			List<Cars> cars = carService.listCarsUser(user.get());
			assertNotNull(cars);
		}
	}
	
	@Test
	public void testUsersLogout() throws Exception{
		mvc.perform(get("/logout"));
	}
	
	@Test
	void testFindCarByName() {
		List<Cars> car = carRepo.searchByParam("BMW");
		assertNotNull(car);
	}

}
